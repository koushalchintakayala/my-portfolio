import { useState, useEffect, useRef } from "react";

const skills = [
  { name: "Java", icon: "fab fa-java" },
  { name: "Python", icon: "fab fa-python" },
  { name: "HTML", icon: "fab fa-html5" },
  { name: "CSS", icon: "fab fa-css3-alt" },
  { name: "JavaScript", icon: "fab fa-js" },
  { name: "TypeScript", icon: "fas fa-code" },
  { name: "React", icon: "fab fa-react" },
  { name: "Git", icon: "fab fa-git-alt" },
  { name: "GitHub", icon: "fab fa-github" },
];

const navLinks = [
  { name: "Home", href: "#home" },
  { name: "About", href: "#about" },
  { name: "Skills", href: "#skills" },
  { name: "Projects", href: "#projects" },
  { name: "Contact", href: "#contact" },
];

function useTypingEffect(words: string[], typingSpeed = 200, deletingSpeed = 100, pauseTime = 2000) {
  const [text, setText] = useState("");
  const [wordIndex, setWordIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const currentWord = words[wordIndex];

    const timeout = setTimeout(() => {
      if (!isDeleting) {
        setText(currentWord.substring(0, text.length + 1));
        if (text === currentWord) {
          setTimeout(() => setIsDeleting(true), pauseTime);
        }
      } else {
        setText(currentWord.substring(0, text.length - 1));
        if (text === "") {
          setIsDeleting(false);
          setWordIndex((prev) => (prev + 1) % words.length);
        }
      }
    }, isDeleting ? deletingSpeed : typingSpeed);

    return () => clearTimeout(timeout);
  }, [text, isDeleting, wordIndex, words, typingSpeed, deletingSpeed, pauseTime]);

  return text;
}

function useScrollReveal() {
  useEffect(() => {
    const revealElements = document.querySelectorAll(".scroll-reveal");

    const checkScroll = () => {
      const triggerBottom = (window.innerHeight / 5) * 4;
      revealElements.forEach((el) => {
        const boxTop = el.getBoundingClientRect().top;
        if (boxTop < triggerBottom) {
          el.classList.add("visible");
        }
      });
    };

    window.addEventListener("scroll", checkScroll);
    checkScroll();
    return () => window.removeEventListener("scroll", checkScroll);
  }, []);
}

function App() {
  const [theme, setTheme] = useState<"dark" | "light">(() => {
    const saved = localStorage.getItem("theme");
    return (saved as "dark" | "light") || "dark";
  });
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("home");

  const typedText = useTypingEffect(["Tech Enthusiast", "Java DSA Solver", "Investor"]);
  useScrollReveal();

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("theme", theme);
  }, [theme]);

  useEffect(() => {
    const handleScroll = () => {
      const sections = document.querySelectorAll("section");
      sections.forEach((section) => {
        const top = window.scrollY;
        const offset = section.offsetTop - 150;
        const height = section.offsetHeight;
        const id = section.getAttribute("id");
        if (top >= offset && top < offset + height && id) {
          setActiveSection(id);
        }
      });
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
    setMobileMenuOpen(false);
  };

  return (
    <>
      {/* Navbar */}
      <nav className="navbar">
        <div className="logo" data-testid="logo">Koushal.</div>
        <ul className={`nav-links ${mobileMenuOpen ? "active" : ""}`}>
          {navLinks.map((link) => (
            <li key={link.name}>
              <a
                className={activeSection === link.href.slice(1) ? "active" : ""}
                onClick={() => scrollToSection(link.href)}
                data-testid={`nav-${link.name.toLowerCase()}`}
              >
                {link.name}
              </a>
            </li>
          ))}
        </ul>
        <div className="nav-extras">
          <div className="theme-switch-wrapper">
            <label className="theme-switch">
              <input
                type="checkbox"
                checked={theme === "light"}
                onChange={() => setTheme(theme === "dark" ? "light" : "dark")}
                data-testid="theme-toggle"
              />
              <div className="slider round"></div>
            </label>
            <i className="fas fa-moon"></i>
          </div>
          <div
            className="hamburger"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            data-testid="hamburger-menu"
          >
            <div></div>
            <div></div>
            <div></div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="hero">
        <div className="hero-content scroll-reveal">
          <h3>Hello, I am</h3>
          <h1>Koushal Chintakayala</h1>
          <h3 className="typing-text">
            I'm a <span className="type-effect">{typedText}</span>
            <span style={{ opacity: 0.7 }}>|</span>
          </h3>
          <div className="social-icons">
            <a
              href="https://www.linkedin.com/in/koushalchintakayala7/"
              target="_blank"
              rel="noopener noreferrer"
              data-testid="social-linkedin"
            >
              <i className="fab fa-linkedin-in"></i>
            </a>
            <a
              href="https://github.com/koushalchintakayala"
              target="_blank"
              rel="noopener noreferrer"
              data-testid="social-github"
            >
              <i className="fab fa-github"></i>
            </a>
            <a
              href="https://leetcode.com/u/koushalchintakayala/"
              target="_blank"
              rel="noopener noreferrer"
              data-testid="social-leetcode"
            >
              <i className="fas fa-code"></i>
            </a>
          </div>
          <div className="hero-btns">
            <a href="#" className="btn" data-testid="button-resume">
              Download Resume
            </a>
            <a
              className="btn btn-secondary"
              onClick={() => scrollToSection("#contact")}
              data-testid="button-contact"
            >
              Contact Me
            </a>
          </div>
        </div>
        <div className="hero-img scroll-reveal">
          <div className="img-box">
            <img src="assets/profile.png" alt="Koushal Chintakayala" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="about">
        <h2 className="section-title">
          About <span>Me</span>
        </h2>
        <div className="about-content">
          <div className="about-text scroll-reveal">
            <p>
              I am an AI/ML undergraduate passionate about solving DSA in Java, building
              modern web apps, and investing in the stock market. I love creating tech
              that solves real-world problems and continuously improving my skills.
            </p>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="skills">
        <h2 className="section-title">
          My <span>Skills</span>
        </h2>
        <div className="skills-container">
          {skills.map((skill, index) => (
            <div className="skill-card scroll-reveal" key={skill.name} data-testid={`skill-card-${index}`}>
              <i className={skill.icon}></i>
              <h3>{skill.name}</h3>
            </div>
          ))}
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="projects">
        <h2 className="section-title">
          Latest <span>Projects</span>
        </h2>
        <div className="projects-container">
          <div className="project-card scroll-reveal" data-testid="project-card-signalist">
            <div className="project-info">
              <h3>Signalist – Stock Screener</h3>
              <p>
                A stock market screening and analysis web app that helps investors
                filter and analyze stocks efficiently.
              </p>
              <div className="tech-stack">
                <span>React</span>
                <span>JavaScript</span>
                <span>APIs</span>
              </div>
              <a
                href="https://github.com/koushalchintakayala/stock-screener"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-icon"
                data-testid="project-github-link"
              >
                <i className="fab fa-github"></i> View Code
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="contact">
        <h2 className="section-title">
          Contact <span>Me</span>
        </h2>
        <div className="contact-container scroll-reveal">
          <div className="contact-info">
            <div className="contact-card" data-testid="contact-phone">
              <i className="fas fa-phone-alt"></i>
              <h4>Phone</h4>
              <p>+91 6304 157622</p>
            </div>
            <div className="contact-card" data-testid="contact-email">
              <i className="fas fa-envelope"></i>
              <h4>Email</h4>
              <p>kc2828@srmist.edu.in</p>
            </div>
            <div className="contact-card" data-testid="contact-linkedin">
              <i className="fab fa-linkedin-in"></i>
              <h4>LinkedIn</h4>
              <a
                href="https://www.linkedin.com/in/koushalchintakayala7/"
                target="_blank"
                rel="noopener noreferrer"
              >
                Connect
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer>
        <p>Copyright &copy; 2024 by Koushal Chintakayala | All Rights Reserved.</p>
        <a className="scroll-top" onClick={() => scrollToSection("#home")} data-testid="button-scroll-top">
          <i className="fas fa-arrow-up"></i>
        </a>
      </footer>
    </>
  );
}

export default App;
